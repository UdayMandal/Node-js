const mongoose=require('mongoose')

//create schema to store in your database
let user=mongoose.Schema({
    "username":{
        type:String,
        unique:true
    },
    "password":{
        type:String,
        required:true
    },
    "email":String,
    "loginhistory":[
        {
        "date":Date,
        "userAgent":String,
        },
    ]
})

//export the schema as "userDetails", this will be collection name in our database
module.exports=mongoose.model("userdetails",user)