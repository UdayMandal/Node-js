// import all the required modules using npm install <module-name>
const express=require('express');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const app=express()
const mongoose=require('mongoose')
const userDetails=require('./models/userModel')

//connect to your database(atlas) account. Replace username and password with your database user and put your
// database name instead of "Users" after "mongodb.net/" 
mongoose.connect("mongodb+srv://hrithik:1234@cluster0.0owerxb.mongodb.net/?retryWrites=true&w=majority").then(()=>{
    console.log('database connected....')
}).catch((err)=>{
    console.log("error connecting database.....")
})

//setting up view engine
app.set("view engine","ejs")

//use middleware to handle the incoming form data from login and signup page and converting to json
app.use(express.urlencoded({extended:true}))
app.use(express.json())

//use middleware to manage session 
app.use(session({
    secret:"ABCDERDGSJH",
    saveUninitialized:true,
    resave:false,
    cookie:{
        maxAge:100*60*60*24,
    }
}))
app.use(cookieParser())

//make login endpoints
app.get('/login',(req,res)=>{
    res.render('login',{msg:""})
})
app.post('/login',(req,res)=>{
    userDetails.findOne({username:req.body.username,password:req.body.password}).then((user)=>{
        if(user==null){
            console.log("user not found")
            res.render('login',{msg:"Account not found"})
        }
        else{
            let history=user.loginhistory;
            let obj={
                date:Date.now(),
                userAgent:req.headers['user-agent']
            }
            history.push(obj)
            userDetails.updateOne({username:req.body.username},{loginhistory:history}).then(()=>{
                console.log("Updated login history")
            }).catch((err)=>{
                console.log(err)
            })
            req.session.username=user.username
            res.redirect("/dashboard")
        }
    })
})

//make signup endpoints
app.get('/signup',(req,res)=>{
    res.render('signup',{msg:"Create Account"})
})
app.post('/signup',(req,res)=>{
    let obj=new userDetails({
        username:req.body.username,
        password:req.body.password,
        email:req.body.password
    })
    obj.save().then((user)=>{
        console.log("user created")
        res.render('login',{msg:"Created Account successfully , Now login"})
    }).catch((err)=>{
        console.log(err)
        res.render("signup",{msg:err})
    })
})

//make dashboard
app.get('/dashboard',(req,res)=>{
    if(req.session.username!=null){
        res.render('dashboard',{msg:req.session.username})
    }
    else{
        res.render('login',{msg:"Login First"})
    }
})

//make logout
app.get('/logout',(req,res)=>{
    req.session.destroy()
    res.redirect('/')
})

//make history page
app.get('/userhistory/:name',(req,res)=>{
    if(req.session.username==null){
        res.render('login',{msg:"Login First"})
    }
    else{
        userDetails.find({username:req.params.name}).then((user)=>{
            if(user!=null){
                res.render("history",{msg:user[0].loginhistory})
            }
        }).catch((err)=>{
            console.log(err)
        })
    }
})
//delete user
app.get('/delete/:name',(req,res)=>{
    userDetails.deleteOne({username:req.params.name}).then((user)=>{
        req.session.destroy()
        res.render('signup',{msg:"User Deleted Successfuly"})
        console.log("Deleted successfull")
    }).catch((err)=>{
        console.log(err)
    })
})
//use middleware to handle static request
app.use(express.static('public'))
app.listen(3000,(err)=>{
    if(err){
        console.log("error connecting to server")
    }
    else{
        console.log("Server connected to port number 3000")
    }
})