
const express = require('express')
const router1 = express.Router()
const path = require('path')

router1.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname , '../public/login.html'))
})

router1.post('/login', (req, res) => {
    if (req.body.username == req.body.password) {
        res.redirect('/user/dashboard')
    }
    else {

        res.redirect('/auth/login')
        }
    // console.log(req.body)
})

module.exports=router1;